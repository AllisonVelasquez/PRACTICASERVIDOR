<form action="" method="post">
    Nombre de Usuario : <input type="text" name="nombre" id="nombre">
    Nombre de Usuario : <input type="text" name="nombre" id="nombre">
    Nombre de Usuario : <input type="text" name="nombre" id="nombre">
    Nombre de Usuario : <input type="text" name="nombre" id="nombre">
    Nombre de Usuario : <input type="text" name="nombre" id="nombre">
    Nombre de Usuario : <input type="text" name="nombre" id="nombre">
</form>